package com.example.roughdraft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{

    private Spinner mySpinner;
    private Button mySearch;
    String choice = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mySpinner = findViewById(R.id.spinner1);
        mySearch = findViewById(R.id.search);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this,R.array.words,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(adapter);

        mySpinner.setOnItemSelectedListener(MainActivity.this);

        //When search button is clicked go to SearchClicked activity
        mySearch.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, SearchClicked.class);
                intent.putExtra("word",choice);
                startActivity(intent);

                /*EditText search = (EditText) findViewById(R.id.searchBar);
                String searchBar = search.getText().toString();

                WordDef definition = new WordDef(searchBar);
                definition.getSearchBar();
                ((TextView) findViewById(R.id.definitionBox)).setText(definition.getWordDefinition());
                ((TextView) findViewById(R.id.wordOrigin)).setText(definition.getWordOfOrigin());*/
            }
        });
    }

    public void buttonClicked(View v)
    {
        EditText search = (EditText) findViewById(R.id.searchBar);
        String searchBar = search.getText().toString();

        WordDef definition = new WordDef(searchBar);
        definition.getSearchBar();
        ((TextView) findViewById(R.id.definitionScreen1)).setText(definition.getWordDefinition());
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
    {
        choice = adapterView.getItemAtPosition(i).toString();
        /*String choice = adapterView.getItemAtPosition(i).toString();*/
        WordDef definition = new WordDef(choice);
        definition.getSearchBar();

        Toast.makeText(MainActivity.this, definition.getWordDefinition(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView)
    {

    }
}