package com.example.roughdraft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MoreClicked extends AppCompatActivity
{

    private Button backD;
    private Button backM;
    TextView word;
    TextView origin;
    String choice ="";
    String org ="";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_clicked);

        backD = findViewById(R.id.backD);
        backM = findViewById(R.id.backM);
        word = findViewById(R.id.wordSearched);
        origin = findViewById(R.id.wordOrigin);

        /* get the data through the intent which you passed in the previous activity*/
        choice = getIntent().getStringExtra("word");
        WordDef d = new WordDef(choice);
        /* search the origin of the word using the getWordOrigin method*/
        org = d.getWordOfOrigin();

        /* display the value of the word and the origin in the text box*/
        word.setText(choice);
        origin.setText(org);

        backD.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MoreClicked.this, SearchClicked.class);
                startActivity(intent);
            }
        });

        backM.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MoreClicked.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}