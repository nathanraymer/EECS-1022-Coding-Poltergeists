package com.example.roughdraft;

public class WordDef
{
    private String searchBar;

    public WordDef()
    {

    }

    public WordDef(String searchBar)
    {
        this.searchBar = searchBar;
    }

    public String getSearchBar()
    {
        return this.searchBar;
    }

    public void setSearchBar(String newSearchBar)
    {
        this.searchBar = newSearchBar;
    }

    public String getWordDefinition()
    {
        String definition = "Definition: ";

        if(searchBar.equalsIgnoreCase("Home"))
        {
            definition += "The place where one lives permanently, especially as a member of a family or household.";
        }
        else if(searchBar.equalsIgnoreCase("Work"))
        {
            definition += "Activity involving mental or physical effort done in order to achieve a purpose or result.";
        }
        else if(searchBar.equalsIgnoreCase("Other"))
        {
            definition += "Denoting a person or thing that is different or distinct from one already mentioned or known about.";
        }
        else if(searchBar.equalsIgnoreCase("Custom"))
        {
            definition += "A traditional and widely accepted way of behaving or doing something that is specific to a particular society, place, or time.";
        }
        else if(searchBar.equalsIgnoreCase("Consumer"))
        {
            definition += "A person who purchases goods and services for personal use.";
        }
        else if(searchBar.equalsIgnoreCase("Brand"))
        {
            definition += "A type of product manufactured by a particular company under a particular name.";
        }
        else if(searchBar.equalsIgnoreCase("Beef"))
        {
            definition += "The flesh of a cow, bull, or ox, used as food.";
        }
        else if(searchBar.equalsIgnoreCase("Hiccup"))
        {
            definition += "An involuntary spasm of the diaphragm and respiratory organs, with a sudden closure of the glottis and a characteristic sound like that of a cough.";
        }
        else if(searchBar.equalsIgnoreCase("Dismissal"))
        {
            definition += "The act of ordering or allowing someone to leave.";
        }
        else if(searchBar.equalsIgnoreCase("Frame"))
        {
            definition += "A rigid structure that surrounds or encloses something such as a door or window.";
        }
        else if(searchBar.equalsIgnoreCase("Grandfather"))
        {
            definition += "The father of one's father or mother.";
        }
        else if(searchBar.equalsIgnoreCase("Integrity"))
        {
            definition += "The quality of being honest and having strong moral principles; moral uprightness.";
        }
        else if(searchBar.equalsIgnoreCase("Distort"))
        {
            definition += "Pull or twist out of shape.";
        }
        else if(searchBar.equalsIgnoreCase("Innovate"))
        {
            definition += "Make changes in something established, especially by introducing new methods, ideas, or products.";
        }
        else if(searchBar.equalsIgnoreCase("Date"))
        {
            definition += "The day of the month or year as specified by a number.";
        }
        else
        {
            definition = "The app does not have the definition for that word";
        }

        return definition;
    }

    public String getWordOfOrigin()
    {
        String origin = "Origin: ";

        if(searchBar.equalsIgnoreCase("Home"))
        {
            origin += "Old English hām, of Germanic origin; related to Dutch heem and German Heim.";
        }
        else if(searchBar.equalsIgnoreCase("Work"))
        {
            origin += "Old English weorc (noun), wyrcan (verb), of Germanic origin; related to Dutch werk and German Werk, from an Indo-European root shared by Greek ergon.";
        }
        else if(searchBar.equalsIgnoreCase("Other"))
        {
            origin += "Old English ōther, of Germanic origin; related to Dutch and German ander, from an Indo-European root meaning ‘different’.";
        }
        else if(searchBar.equalsIgnoreCase("Custom"))
        {
            origin += "Middle English: from Old French coustume, based on Latin consuetudo, from consuetus, past participle of consuescere ‘accustom’, from con- (expressing intensive force) + suescere ‘become accustomed’.";
        }
        else if(searchBar.equalsIgnoreCase("Consumer"))
        {
            origin += "late Middle English: from Latin consumere, from con- ‘altogether’ + sumere ‘take up’; reinforced by French consumer .";
        }
        else if(searchBar.equalsIgnoreCase("Brand"))
        {
            origin += "Old English brand ‘burning’ (also in brand (sense 3 of the noun)), of Germanic origin; related to German Brand, also to burn1. The verb sense ‘mark with a hot iron’ dates from late Middle English, giving rise to the noun sense ‘a mark of ownership made by branding’ (mid 17th century), whence brand (sense 1 of the noun) (early 19th century).";
        }
        else if(searchBar.equalsIgnoreCase("Beef"))
        {
            origin += "Middle English: from the Latin word bos (and the stem bov-), meaning cow";
        }
        else if(searchBar.equalsIgnoreCase("Hiccup"))
        {
            origin += "Old English: word for it was ælfsogoða, \"elf heartburn,\" since hiccups were thought to be caused by elves.";
        }
        else if(searchBar.equalsIgnoreCase("Dismissal"))
        {
            origin += "The word comes from dismiss, \"send away,\" from the Latin root dimittere, \"send different ways\" or \"break up.\"";
        }
        else if(searchBar.equalsIgnoreCase("Frame"))
        {
            origin += "Old English framian ‘be useful’, of Germanic origin and related to from. The general sense in Middle English, ‘make ready for use’, probably led to frame (sense 2 of the verb); it also gave rise to the specific meaning ‘prepare timber for use in building’, later ‘make the wooden parts (framework) of a building’, hence the noun sense ‘structure’ (late Middle English).";
        }
        else if(searchBar.equalsIgnoreCase("Grandfather"))
        {
            origin += "The noun is derived from Middle English grandfadre, graundfadir, graunfadir, grauntfader, and other forms, from graunt (“big, large; great, important”)[1] + fā̆der (“male parent, father; remoter male ancestor”),[2] probably modelled after Middle French grandpere, grant pere (“male parent; remoter male ancestor”) (whence French grand-père)";
        }
        else if(searchBar.equalsIgnoreCase("Integrity"))
        {
            origin += "The word integrity evolved from the Latin adjective integer, meaning whole or complete. It is defined as 'an undivided or unbroken completeness', or 'a state of being complete or whole'.";
        }
        else if(searchBar.equalsIgnoreCase("Distort"))
        {
            origin += "From Latin distortus, past participle of distorquere \"to twist different ways, distort,\" from dis- \"completely\" (see dis-) + torquere \"to twist\" (from PIE root *terkw- \"to twist\").";
        }
        else if(searchBar.equalsIgnoreCase("Innovate"))
        {
            origin += "From the Latin word “novus” meaning new. Creating something new is the goal of most innovation initiatives, but new does not mean valuable.";
        }
        else if(searchBar.equalsIgnoreCase("Date"))
        {
            origin += "From Latin, but the Latin word did not mean either \"day\" or \"time.\" Date derives from the Latin phrase data Romae, meaning \"given at Rome,\" an expression used just before the date on letters and documents.";
        }
        else
        {
            origin = "The app does not have the origin for that word";
        }

        return origin;
    }
}
