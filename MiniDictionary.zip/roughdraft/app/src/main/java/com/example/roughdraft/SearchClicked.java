package com.example.roughdraft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SearchClicked extends AppCompatActivity
{

    private Button back;
    TextView word;
    TextView definition;
    TextView origin;
    String choice = "";
    String def = "";
    String org = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_clicked);


        back = findViewById(R.id.back);
        word = findViewById(R.id.wordSearched);
//define the definition box here
        definition = findViewById(R.id.definitionBox);
        origin = findViewById(R.id.wordOrigin2);

        /* get the data through the intent which you passed in the previous activity*/
        choice = getIntent().getStringExtra("word");
        WordDef d = new WordDef(choice);
        /* search the definition of the word using the getWordDefinition method*/
        def = d.getWordDefinition();
        org = d.getWordOfOrigin();

        /* display the value of the word and the definition in the text box*/
        word.setText(choice);
        definition.setText(def);
        origin.setText(org);


        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(SearchClicked.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}