package com.example.roughdraft;

public class WordDef
{
    private static final String wordList[] = {"Home","Work","Other","Custom"};
    private String searchBar;

    public WordDef()
    {

    }

    public WordDef(String searchBar)
    {
        this.searchBar = searchBar;
    }

    public String getSearchBar()
    {
        return this.searchBar;
    }

    public void setSearchBar(String newSearchBar)
    {
        this.searchBar = newSearchBar;
    }

    //Probably better to use a for-loop instead of a bunch of if-else statements
    public String getWordDefinition()
    {
        String definition = "";

        if(searchBar == "Home")
        {
            definition = "The place where one lives permanently, especially as a member of a family or household.";
        }
        else if(searchBar == "Work")
        {
            definition = "Activity involving mental or physical effort done in order to achieve a purpose or result.";
        }
        else if(searchBar == "Other")
        {
            definition = "Denoting a person or thing that is different or distinct from one already mentioned or known about.";
        }
        else if(searchBar == "Custom")
        {
            definition = "A traditional and widely accepted way of behaving or doing something that is specific to a particular society, place, or time.";
        }

        return definition;
    }
}
