package com.example.roughdraft;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{

    private Spinner mySpinner;
    private Button mySearch;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mySpinner = findViewById(R.id.spinner1);
        mySearch = findViewById(R.id.search);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this,R.array.words,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(adapter);

        mySpinner.setOnItemSelectedListener(MainActivity.this);

        //When search button is clicked go to SearchClicked activity
        mySearch.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainActivity.this, SearchClicked.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
    {
        String choice = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView)
    {

    }

    public void buttonClicked(View v)
    {
        EditText searchView = (EditText) findViewById(R.id.searchBar);
        String sB = searchView.getText().toString(); //sb = Home

        WordDef searchB = new WordDef();
        searchB.setSearchBar(sB);
        searchB.getSearchBar();
        String def = searchB.getWordDefinition(); //def = The place where one lives permanently, especially as a member of a family or household.
        ((TextView) findViewById(R.id.definition)).setText(def);
    }

}