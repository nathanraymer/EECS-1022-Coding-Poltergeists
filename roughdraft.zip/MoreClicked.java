package com.example.roughdraft;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MoreClicked extends AppCompatActivity
{

    private Button backD;
    private Button backM;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_clicked);

        backD = findViewById(R.id.backD);
        backM = findViewById(R.id.backM);

        backD.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MoreClicked.this, SearchClicked.class);
                startActivity(intent);
            }
        });

        backM.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MoreClicked.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}