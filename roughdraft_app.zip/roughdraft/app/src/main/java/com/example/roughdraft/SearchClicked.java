package com.example.roughdraft;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SearchClicked extends AppCompatActivity
{

    private Button more;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_clicked);

        more = findViewById(R.id.more);
        back = findViewById(R.id.back);

        more.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(SearchClicked.this, MoreClicked.class);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(SearchClicked.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}