package com.example.roughdraft;

public class WordDef
{
    private static final String wordList[] = {"Home","Work","Other","Custom"};
    private String searchBar;

    public WordDef()
    {

    }

    public WordDef(String searchBar)
    {
        this.searchBar = searchBar;
    }

    public String getSearchBar()
    {
        return this.searchBar;
    }

    public void setSearchBar(String newSearchBar)
    {
        this.searchBar = newSearchBar;
    }

    //Probably better to use a for-loop instead of a bunch of if-else statements
    public String getWordDefinition()
    {
        String definition = "Definition: ";

        if(searchBar.equalsIgnoreCase("Home"))
        {
            definition += "The place where one lives permanently, especially as a member of a family or household.";
        }
        else if(searchBar.equalsIgnoreCase("Work"))
        {
            definition += "Activity involving mental or physical effort done in order to achieve a purpose or result.";
        }
        else if(searchBar.equalsIgnoreCase("Other"))
        {
            definition += "Denoting a person or thing that is different or distinct from one already mentioned or known about.";
        }
        else if(searchBar.equalsIgnoreCase("Custom"))
        {
            definition += "A traditional and widely accepted way of behaving or doing something that is specific to a particular society, place, or time.";
        }

        return definition;
    }

    public String getWordOfOrigin()
    {
        String origin = "Origin: ";

        if(searchBar.equalsIgnoreCase("Home"))
        {
            origin += "Old English hām, of Germanic origin; related to Dutch heem and German Heim.";
        }
        else if(searchBar.equalsIgnoreCase("Work"))
        {
            origin += "Old English weorc (noun), wyrcan (verb), of Germanic origin; related to Dutch werk and German Werk, from an Indo-European root shared by Greek ergon.";
        }
        else if(searchBar.equalsIgnoreCase("Other"))
        {
            origin += "Old English ōther, of Germanic origin; related to Dutch and German ander, from an Indo-European root meaning ‘different’.";
        }
        else if(searchBar.equalsIgnoreCase("Custom"))
        {
            origin += "Middle English: from Old French coustume, based on Latin consuetudo, from consuetus, past participle of consuescere ‘accustom’, from con- (expressing intensive force) + suescere ‘become accustomed’.";
        }

        return origin;
    }
}
